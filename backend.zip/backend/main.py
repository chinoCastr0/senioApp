# main.py
import os
import uuid
import base64
import time
import asyncio
from io import BytesIO
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, Form, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from utils.pdf_creator import create_photocopy_grid_pdf

app = FastAPI()

# --- CORS (ajustá orígenes en prod) ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # en prod, especificar dominios
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Storage: crear y servir /uploads ---
BASE_UPLOAD_DIR = Path("uploads")
PDFS_DIR = BASE_UPLOAD_DIR / "pdfs"
PDFS_DIR.mkdir(parents=True, exist_ok=True)

# Monta /uploads para acceso público (PDF.js)
app.mount("/uploads", StaticFiles(directory=str(BASE_UPLOAD_DIR)), name="uploads")

# --- Config de limpieza (TTL) ---
RETENTION_SECONDS = 1 # 30 minutos


@app.post("/generar-pdf")
async def generar_pdf(
    request: Request,
    file: UploadFile = File(...),
    altoMm: float = Form(...),
    anchoMm: float = Form(...),
    cantidad: int = Form(...),
):
    # Convertir imagen a data URL (tu generador lo espera así)
    image_bytes = await file.read()
    image_base64 = base64.b64encode(image_bytes).decode("utf-8")
    image_data_url = f"data:{file.content_type};base64,{image_base64}"

    layout_data = {"altoMm": altoMm, "anchoMm": anchoMm, "cantidad": cantidad}

    # Generar PDF en memoria
    pdf_buffer: BytesIO = create_photocopy_grid_pdf(image_data_url, layout_data)

    # Guardar PDF
    filename = f"grilla_{uuid.uuid4().hex}.pdf"
    disk_path = os.path.join("uploads", "pdfs", filename)
    with open(disk_path, "wb") as f:
        f.write(pdf_buffer.getvalue())

    # URL pública
    base = str(request.base_url).rstrip("/")
    pdf_path = f"/uploads/pdfs/{filename}"
    pdf_url = f"{base}{pdf_path}"

    return JSONResponse({
        "pdf_url": pdf_url,
        "pdf_path": pdf_path,
        "filename": filename
    })


# -------------------------------
# Barredor automático de PDFs viejos
# -------------------------------
async def _sweeper_loop():
    while True:
        now = time.time()
        try:
            for p in PDFS_DIR.iterdir():
                if p.is_file():
                    try:
                        age = now - p.stat().st_mtime
                        if age > RETENTION_SECONDS:
                            p.unlink(missing_ok=True)
                            print(f"[SWEEP] Borrado: {p.name}")
                    except Exception as e:
                        print(f"[SWEEP WARN] {p.name}: {e}")
        except Exception as e:
            print(f"[SWEEP FATAL] {e}")
        await asyncio.sleep(300)  # corre cada 5 minutos


@app.on_event("startup")
async def _startup():
    asyncio.create_task(_sweeper_loop())


# Opcional: healthcheck rápido
@app.get("/")
async def root():
    return {"ok": True}
